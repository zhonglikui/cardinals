package com.zhong.cardinals.sample.mode

/**
 * Created by zhong on 2017/3/28.
 */

class UserInfo {
    var userId: Long = 0//": 307111,
    var nick: String? = null//": "xxx",  //用户昵称
    var isNew: Boolean = false//": false,  //只有老用户能用这个登录
    var figureUrl: String? = null//": "some url",  //头像地址
    var isPasswordSet: Boolean = false//": false  //是否已经设置密码
    var isInfoSet: Boolean = false//" : true //用户基本信息是否已经设置
}


