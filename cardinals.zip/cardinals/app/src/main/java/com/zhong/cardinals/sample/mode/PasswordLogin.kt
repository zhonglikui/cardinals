package com.zhong.cardinals.sample.mode

/**
 * Created by zhong on 2017/3/28.
 */

class PasswordLogin {
    var phone: String? = null
    var regionCode: String? = null
    var password: String? = null

}
