package com.zhong.cardinals.net;

/**
 * Created by zhong on 2018/1/20.
 */

public interface NetInterface {
    void onResult(int code);
}
