package com.zhong.cardinals.mvp;

/**
 * Created by Mr.zhong on 2017/9/19.
 */
//高度抽象的V层
public interface MvpView {
}
